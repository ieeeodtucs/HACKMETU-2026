#!/usr/bin/env python3
"""Interactive setup helper for OperationScore agent.

Writes /etc/operationscore/agent.env and restarts the systemd service.
"""
import getpass
import os
import re
import socket
import subprocess
import sys
from pathlib import Path


def detect_ip():
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        try:
            s.connect(("8.8.8.8", 80))
            ip = s.getsockname()[0]
        finally:
            s.close()
        return ip
    except Exception:
        return "127.0.0.1"


def ask(prompt, default=None):
    if default:
        p = f"{prompt} [{default}]: "
    else:
        p = f"{prompt}: "
    v = input(p).strip()
    return v if v else (default or "")


def validate_url(u: str) -> bool:
    return bool(re.match(r'^https?://', u))


def main():
    if os.geteuid() != 0:
        print("This tool must be run as root", file=sys.stderr)
        sys.exit(1)

    hostname = socket.gethostname()
    default_report = f"http://SERVER_IP:8000/report"
    default_register = f"http://SERVER_IP:8000/api/register"

    print("Interactive OperationScore Agent Setup")
    report_url = ask("OPS_REPORT_URL", default_report)
    while not validate_url(report_url):
        print("URL must start with http:// or https://")
        report_url = ask("OPS_REPORT_URL", default_report)

    register_url = ask("OPS_REGISTER_URL", default_register)
    while not validate_url(register_url):
        print("URL must start with http:// or https://")
        register_url = ask("OPS_REGISTER_URL", default_register)

    register_user = ask("OPS_REGISTER_USER", "ops-client")
    while True:
        register_pass = getpass.getpass("OPS_REGISTER_PASS: ")
        if register_pass:
            break
        print("Password cannot be empty")

    ops_hostname = ask("OPS_HOSTNAME", hostname)
    ops_ip = ask("OPS_REGISTER_IP", detect_ip())
    poll = ask("OPS_POLL_INTERVAL_SECONDS", "10")

    env_path = Path("/etc/operationscore/agent.env")
    env_path.parent.mkdir(parents=True, exist_ok=True)
    content = (
        f"OPS_REPORT_URL={report_url}\n"
        f"OPS_REGISTER_URL={register_url}\n"
        f"OPS_REGISTER_USER={register_user}\n"
        f"OPS_REGISTER_PASS={register_pass}\n"
        f"OPS_HOSTNAME={ops_hostname}\n"
        f"OPS_REGISTER_IP={ops_ip}\n"
        f"OPS_POLL_INTERVAL_SECONDS={poll}\n"
    )

    env_path.write_text(content, encoding="utf-8")
    os.chmod(env_path, 0o600)
    try:
        subprocess.run(["chown", "root:root", str(env_path)], check=False)
    except Exception:
        pass

    print(f"Wrote {env_path}")

    # Restart service if possible
    if shutil_which("systemctl"):
        subprocess.run(["systemctl", "daemon-reload"], check=False)
        subprocess.run(["systemctl", "restart", "operationscore-agent"], check=False)
        print("Restarted operationscore-agent (if present). Check journalctl -u operationscore-agent -f")
    else:
        print("systemctl not found; please restart the service manually")


def shutil_which(cmd):
    from shutil import which

    return which(cmd) is not None


if __name__ == "__main__":
    main()
